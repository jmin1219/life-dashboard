const InvestmentsTab = () => {
  return <div className="">InvestmentsTab</div>;
};

export default InvestmentsTab;
