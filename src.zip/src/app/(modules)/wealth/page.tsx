import WealthOverviewTab from "./overview/page";

const WealthPage = async () => {
  return <WealthOverviewTab />;
};

export default WealthPage;
