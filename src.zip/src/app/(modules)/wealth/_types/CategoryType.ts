export interface CategoryType {
  id: number;
  name: string;
  type: string;
  icon: string;
  color: string;
}
