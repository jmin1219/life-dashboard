export interface NetWorthLogType {
  id: number;
  totalAssets: number;
  totalLiabilities: number;
  netWorth: number;
  date: number;
}
