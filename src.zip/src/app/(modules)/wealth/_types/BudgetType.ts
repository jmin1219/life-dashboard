export interface BudgetType {
  id: number;
  categoryId: number;
  amount: number;
  period: string;
  createdAt: number;
}
