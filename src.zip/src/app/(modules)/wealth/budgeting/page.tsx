const BudgetGoalsTab = () => {
  return <div className="">BudgetGoalsTab</div>;
};

export default BudgetGoalsTab;
