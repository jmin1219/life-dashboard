const WealthOverviewTab = () => {
  return <div className="">WealthOverviewTab</div>;
};

export default WealthOverviewTab;
