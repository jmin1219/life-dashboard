const ProductivityPage = () => {
  return <div className="">ProductivityPage</div>;
};

export default ProductivityPage;
