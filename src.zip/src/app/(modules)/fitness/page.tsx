const FitnessPage = () => {
  return <div className="">FitnessPage</div>;
};

export default FitnessPage;
